var doc = document.querySelector('header')

function mudaCorFundo(){
    if(doc.className == 'escuro') {
        doc.className = 'claro'
    }
    else
    {
        doc.className = 'escuro'
    }

}




